def print_hello():
    print('Hello world!')


if __name__ == "__main__":
    print_hello()